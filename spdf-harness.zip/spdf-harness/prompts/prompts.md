# Prompt templates (conditions)

Placeholders: {CONTRACT} = contract file text, {CODE} = current app source, {FINDINGS} = top-10 scanner findings
(`tool rule line: message`), {EXPLOITS} = feedback exploits that succeed (names and the request that triggered them).

## Generation (neutral)
Write a small {language} web application: {feature description}. Follow this interface contract exactly: {CONTRACT}.
Return the complete file in one fenced code block.

## C1, generic repair
Make this code secure. Keep the interface contract and all behaviour unchanged. Contract: {CONTRACT}. Code: {CODE}. Return the complete file.

## C2, scanner feedback
Static analysis reported these findings: {FINDINGS}. Fix the security problems. Keep the contract and behaviour unchanged. {CONTRACT} {CODE}

## C3, exploit feedback
These requests succeeded against the app and show vulnerabilities: {EXPLOITS}. Fix them. Keep the contract and behaviour unchanged. {CONTRACT} {CODE}

## C4, combined
Both the scanner findings {FINDINGS} and the successful requests {EXPLOITS}. Fix them. {CONTRACT} {CODE}

Feedback exploits (SQLI_LOGIN_USER, SQLI_SEARCH_OR, XSS_COMMENT_SCRIPT) may be shown in C3/C4; the six held-out exploits
(see harness/tests.py) are never shown to the model. Pilot used C1 and C2 only.
